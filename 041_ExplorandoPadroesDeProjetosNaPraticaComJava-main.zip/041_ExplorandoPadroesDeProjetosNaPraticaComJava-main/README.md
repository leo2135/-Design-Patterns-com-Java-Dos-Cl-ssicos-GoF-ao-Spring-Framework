# Labs

## 041_ExplorandoPadroesDeProjetosNaPraticaComJava

Agora é a sua hora de brilhar! Crie uma solução que explore o conceito de Padrões de Projeto na prática. Para isso, você pode reproduzir um dos projetos que criamos durante as aulas ou, caso se sinta preparado, desenvolver uma nova ideia do zero.  JavaSpring BootSpring Data 

JavaSpring BootSpring Data
Full-Stack Intermediário 

### ESPECIALISTA

#### Venilton FalvoJr
Tech Lead, Digital Innovation One

https://web.dio.me/lab/explorando-padroes-de-projetos-na-pratica-com-java/learning/5d129c4b-11fc-40b3-a4b0-cceeb1cd5d29
