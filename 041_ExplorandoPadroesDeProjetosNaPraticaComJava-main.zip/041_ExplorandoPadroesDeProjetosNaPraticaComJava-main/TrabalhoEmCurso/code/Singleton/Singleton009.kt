  public object Singleton {
    public fun facaAlgumaCoisa() {
      //Aqui será feito alguma coisa legal
    }
  }

  // O singleton é usado assim:
  Singleton.facaAlgumaCoisa()