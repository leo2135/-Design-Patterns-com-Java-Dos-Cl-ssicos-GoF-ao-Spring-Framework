require 'singleton'

class Foobar
    include Singleton
end